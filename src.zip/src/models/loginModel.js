// src/models/loginModel.js
const mongoose = require('mongoose');
 
const loginSchema = new mongoose.Schema({
  employee_id: {
    type: Number,
    required: true,
    unique: true
  },
  employee_ref_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    required: true
  },
  password: {
    type: String,
    required: true
  },
  // hold the single active token (null when logged out)
  activeToken: {
    type: String,
    default: null
  }
}, { collection: 'login' });
 
module.exports = mongoose.model('Login', loginSchema);